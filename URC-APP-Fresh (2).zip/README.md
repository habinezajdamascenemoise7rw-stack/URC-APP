# URC APP

Clean Flutter starter for URC. GitHub Actions builds the Android APK in the cloud.
